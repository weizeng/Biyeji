#import "UmengAnalyticsPlugin.h"
#import "MobClick.h"
#import <Cordova/CDVPluginResult.h>

@implementation UmengAnalyticsPlugin

- (void)init:(CDVInvokedUrlCommand*)command
{
    NSString* callbackId = command.callbackId;
    [MobClick startWithAppkey:@"5598ee6867e58e42e9002113" reportPolicy:BATCH   channelId:@"Web"];

    CDVPluginResult* pluginResult = nil;
    [self.commandDelegate sendPluginResult:pluginResult callbackId:callbackId];
}

@end
