#import <Cordova/CDVPlugin.h>

@interface UmengAnalyticsPlugin : CDVPlugin

- (void)init:(CDVInvokedUrlCommand*)command;

@end